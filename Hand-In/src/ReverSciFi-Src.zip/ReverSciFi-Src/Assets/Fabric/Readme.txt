Fabric v2.2.0
--------------

Fabric extends Unity�s audio functionality and provides a set of high level audio components and editor extensions that allowes the creation of complex and rich audio behaviors.

To install Fabric you simple need to import the Fabric.package into your project. The package comes with DLL assemblies, documentation and a number of tutorials scenes.




